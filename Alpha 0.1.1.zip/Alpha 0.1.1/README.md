# Under-Earth

Under-Earth is a procedurally-generated adventure game set in the deep, twisting cave systems and sprawling labryinths underneath the earth's surface.

-Mine for recourses and craft powerful tools.
-Explore abandoned cities and find the great subterainian foes that once plagued them.
